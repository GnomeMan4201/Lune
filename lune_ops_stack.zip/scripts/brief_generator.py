# placeholder for intel brief gen script
print('Generating LUNE intel brief...')